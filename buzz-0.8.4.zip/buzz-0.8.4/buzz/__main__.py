import buzz.buzz

if __name__ == "__main__":
    buzz.buzz.main()
